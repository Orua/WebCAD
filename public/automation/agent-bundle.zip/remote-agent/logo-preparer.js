// src/agent/logo-preparer.mjs
import { readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";

// src/logo-model.js
var EPS = 1e-9;
var finite = (value, name) => {
  if (typeof value !== "number" || !Number.isFinite(value)) throw new Error(`${name} must be finite`);
  return value;
};
var cross2 = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
function readRing(input2, label, maxVertices = 64e3) {
  if (!Array.isArray(input2)) throw new Error(`${label} must be an array`);
  const points = input2.map((p, i) => {
    if (!Array.isArray(p) || p.length !== 2) throw new Error(`${label}[${i}] must be [x,y]`);
    return [finite(p[0], `${label}[${i}].x`), finite(p[1], `${label}[${i}].y`)];
  });
  if (points.length > 3 && points[0][0] === points.at(-1)[0] && points[0][1] === points.at(-1)[1]) points.pop();
  if (points.length < 3 || points.length > maxVertices) throw new Error(`${label} must have 3..${maxVertices} vertices`);
  const unique = /* @__PURE__ */ new Set();
  for (let i = 0; i < points.length; i++) {
    const a = points[i], b = points[(i + 1) % points.length];
    if (a[0] === b[0] && a[1] === b[1]) throw new Error(`${label} has duplicate adjacent vertices`);
    const key = `${a[0]},${a[1]}`;
    if (unique.has(key)) throw new Error(`${label} repeats a vertex`);
    unique.add(key);
    const c = points[(i + 2) % points.length];
    if (Math.abs(cross2(a, b, c)) <= EPS && (b[0] - a[0]) * (c[0] - b[0]) + (b[1] - a[1]) * (c[1] - b[1]) < 0) throw new Error(`${label} doubles back over an edge`);
  }
  let area2 = 0;
  for (let i = 0; i < points.length; i++) {
    const a = points[i], b = points[(i + 1) % points.length];
    area2 += a[0] * b[1] - b[0] * a[1];
  }
  if (!Number.isFinite(area2) || Math.abs(area2) <= EPS) throw new Error(`${label} has zero area`);
  return points;
}
function onSegment(p, a, b, tol) {
  return Math.abs(cross2(a, b, p)) <= tol * Math.max(1, Math.hypot(b[0] - a[0], b[1] - a[1])) && p[0] >= Math.min(a[0], b[0]) - tol && p[0] <= Math.max(a[0], b[0]) + tol && p[1] >= Math.min(a[1], b[1]) - tol && p[1] <= Math.max(a[1], b[1]) + tol;
}
function segmentsMeet(a, b, c, d, tol) {
  const ab1 = cross2(a, b, c), ab2 = cross2(a, b, d), cd1 = cross2(c, d, a), cd2 = cross2(c, d, b);
  if ((ab1 > tol && ab2 < -tol || ab1 < -tol && ab2 > tol) && (cd1 > tol && cd2 < -tol || cd1 < -tol && cd2 > tol)) return true;
  return onSegment(c, a, b, tol) || onSegment(d, a, b, tol) || onSegment(a, c, d, tol) || onSegment(b, c, d, tol);
}
function pointInRing(point, ring) {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const a = ring[j], b = ring[i];
    if (a[1] > point[1] !== b[1] > point[1] && point[0] < (b[0] - a[0]) * (point[1] - a[1]) / (b[1] - a[1]) + a[0]) inside = !inside;
  }
  return inside;
}
function boundariesMeet(ringA, ringB, budget) {
  const aEdges = ringA.map((a, i) => [a, ringA[(i + 1) % ringA.length]]);
  const bEdges = ringA === ringB ? [] : ringB.map((a, i) => [a, ringB[(i + 1) % ringB.length]]);
  const entries = [
    ...aEdges.map((edge, i) => ({ edge, ring: 0, i })),
    ...bEdges.map((edge, i) => ({ edge, ring: 1, i }))
  ].map((e) => ({ ...e, minX: Math.min(e.edge[0][0], e.edge[1][0]), maxX: Math.max(e.edge[0][0], e.edge[1][0]), minY: Math.min(e.edge[0][1], e.edge[1][1]), maxY: Math.max(e.edge[0][1], e.edge[1][1]) })).sort((a, b) => a.minX - b.minX);
  const active = [];
  let checked = 0;
  for (const e of entries) {
    let keep = 0;
    for (const other of active) {
      if (other.maxX < e.minX - budget.tol) continue;
      active[keep++] = other;
      if (other.maxY < e.minY - budget.tol || e.maxY < other.minY - budget.tol) continue;
      if (e.ring === other.ring) {
        const n = e.ring === 0 ? ringA.length : ringB.length;
        const distance2 = Math.abs(e.i - other.i);
        if (distance2 === 0) continue;
        if (distance2 === 1 || distance2 === n - 1) continue;
      }
      if (++checked > budget.maxCandidates) throw new Error("contours exceed safe exact-validation complexity; simplify the outlines");
      if (segmentsMeet(e.edge[0], e.edge[1], other.edge[0], other.edge[1], budget.tol)) return true;
    }
    active.length = keep;
    active.push(e);
  }
  return false;
}
function ringContainsRing(parent, child) {
  return pointInRing(child[0], parent);
}
function inspectLogoMachiningCapacity(logo2) {
  const regions = logo2.regions ?? [], rings2 = regions.flatMap((r) => [r.outer, ...r.holes ?? []]);
  const counts = { regions: regions.length, vertices: rings2.reduce((sum, r) => sum + r.length, 0), maxRingVertices: rings2.reduce((max, r) => Math.max(max, r.length), 0) };
  const limits = { regions: 150, vertices: 12e3, maxRingVertices: 2e3 };
  const supported = Object.keys(limits).every((key) => counts[key] <= limits[key]);
  return { supported, counts, limits, code: supported ? null : "CONTOUR_TOO_COMPLEX", reason: supported ? null : `\u8F6E\u5ED3\u5DF2\u8BC6\u522B\uFF0C\u4F46\u6709 ${counts.regions} \u4E2A\u533A\u57DF\u3001${counts.vertices} \u4E2A\u9876\u70B9\uFF08\u6700\u5927\u5355\u73AF ${counts.maxRingVertices} \u70B9\uFF09\uFF0C\u8D85\u8FC7\u5F53\u524D\u5B9E\u4F53\u96D5\u523B\u4E0A\u9650\uFF1A150 \u533A\u57DF\u3001\u603B\u8BA1 12000 \u70B9\u3001\u6BCF\u73AF 2000 \u70B9\u3002\u53EF\u7EE7\u7EED\u6821\u5BF9\u548C\u5BFC\u51FA\u8F6E\u5ED3\uFF0C\u6682\u4E0D\u80FD\u76F4\u63A5\u96D5\u523B\u3002` };
}
function validateRegions(params, { maxRegions = 1024, maxVertices = 64e3, maxRingVertices = 64e3 } = {}) {
  const raw2 = params.regions;
  if (!Array.isArray(raw2) || raw2.length < 1 || raw2.length > maxRegions) throw new Error(`regions must contain 1..${maxRegions} regions`);
  let declaredPoints = 0;
  for (const [ri, region] of raw2.entries()) {
    if (!region || typeof region !== "object" || !Array.isArray(region.outer)) throw new Error(`region ${ri} is invalid`);
    const holes = region.holes ?? [];
    if (!Array.isArray(holes)) throw new Error(`regions[${ri}].holes must be an array`);
    declaredPoints += region.outer.length;
    for (const hole of holes) {
      if (!Array.isArray(hole)) throw new Error(`region ${ri} has an invalid hole`);
      declaredPoints += hole.length;
    }
    if (declaredPoints > maxVertices) throw new Error(`total contour vertices exceed ${maxVertices}`);
  }
  let total = 0;
  const regions = raw2.map((region, ri) => {
    if (!region || typeof region !== "object") throw new Error(`region ${ri} is invalid`);
    const outer = readRing(region.outer, `regions[${ri}].outer`, maxRingVertices), holesRaw = region.holes ?? [];
    if (!Array.isArray(holesRaw)) throw new Error(`regions[${ri}].holes must be an array`);
    const holes = holesRaw.map((h, hi) => readRing(h, `regions[${ri}].holes[${hi}]`, maxRingVertices));
    total += outer.length + holes.reduce((s, h) => s + h.length, 0);
    if (total > maxVertices) throw new Error(`total contour vertices exceed ${maxVertices}`);
    return { outer, holes };
  });
  const budget = { tol: EPS, maxCandidates: 2e6 };
  const rings2 = regions.flatMap((region, ri) => [region.outer, ...region.holes].map((points, hi) => ({ points, ri, hi })));
  for (const { points, ri, hi } of rings2) {
    if (boundariesMeet(points, points, budget)) throw new Error(`region ${ri} contour ${hi} self-intersects or touches`);
  }
  for (const region of regions) {
    for (const hole of region.holes) {
      if (!ringContainsRing(region.outer, hole)) throw new Error("hole lies outside its outer contour");
      if (boundariesMeet(region.outer, hole, budget)) throw new Error("hole touches or crosses its outer contour");
    }
    for (let i = 0; i < region.holes.length; i++) for (let j = i + 1; j < region.holes.length; j++) {
      if (boundariesMeet(region.holes[i], region.holes[j], budget) || ringContainsRing(region.holes[i], region.holes[j]) || ringContainsRing(region.holes[j], region.holes[i])) throw new Error("holes overlap, touch, or contain one another");
    }
  }
  const bounds = regions.map((r) => r.outer.reduce((b, p) => [Math.min(b[0], p[0]), Math.min(b[1], p[1]), Math.max(b[2], p[0]), Math.max(b[3], p[1])], [Infinity, Infinity, -Infinity, -Infinity]));
  for (let i = 0; i < regions.length; i++) for (let j = i + 1; j < regions.length; j++) {
    const u = bounds[i], v = bounds[j];
    if (u[2] < v[0] - EPS || v[2] < u[0] - EPS || u[3] < v[1] - EPS || v[3] < u[1] - EPS) continue;
    const a = regions[i], b = regions[j];
    for (const ra of [a.outer, ...a.holes]) for (const rb of [b.outer, ...b.holes]) if (boundariesMeet(ra, rb, budget)) throw new Error(`regions ${i} and ${j} touch or overlap`);
    const aInB = ringContainsRing(b.outer, a.outer) && !b.holes.some((h) => pointInRing(a.outer[0], h));
    const bInA = ringContainsRing(a.outer, b.outer) && !a.holes.some((h) => pointInRing(b.outer[0], h));
    if (aInB || bInA) throw new Error(`regions ${i} and ${j} overlap`);
  }
  return regions;
}

// src/logo-contour-fit.js
var dist = (p, a, b) => {
  const x = b[0] - a[0], y = b[1] - a[1], t = Math.max(0, Math.min(1, ((p[0] - a[0]) * x + (p[1] - a[1]) * y) / (x * x + y * y || 1)));
  return Math.hypot(p[0] - a[0] - t * x, p[1] - a[1] - t * y);
};
var gap = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
function lineFit(points, tolerance) {
  const n = points.length, c = points.reduce((s, p) => [s[0] + p[0] / n, s[1] + p[1] / n], [0, 0]);
  let xx = 0, xy = 0, yy = 0;
  for (const p of points) {
    const x = p[0] - c[0], y = p[1] - c[1];
    xx += x * x;
    xy += x * y;
    yy += y * y;
  }
  const angle = 0.5 * Math.atan2(2 * xy, xx - yy), v = [Math.cos(angle), Math.sin(angle)], project = (p) => {
    const t = (p[0] - c[0]) * v[0] + (p[1] - c[1]) * v[1];
    return [c[0] + t * v[0], c[1] + t * v[1]];
  };
  const a = project(points[0]), b = project(points.at(-1));
  if (gap(a, b) < tolerance) return null;
  if (points.some((p) => dist(p, a, b) > tolerance * 0.72)) return null;
  return { kind: "line", points: [a, b] };
}
function circleFit(points, tolerance) {
  if (points.length < 5) return null;
  const n = points.length, c = points.reduce((s, p) => [s[0] + p[0] / n, s[1] + p[1] / n], [0, 0]);
  let xx = 0, xy = 0, yy = 0, xz = 0, yz = 0;
  for (const p of points) {
    const x = p[0] - c[0], y = p[1] - c[1], z = x * x + y * y;
    xx += x * x;
    xy += x * y;
    yy += y * y;
    xz += x * z;
    yz += y * z;
  }
  const det = xx * yy - xy * xy;
  if (Math.abs(det) < 1e-18) return null;
  const center = [c[0] + (xz * yy - yz * xy) / (2 * det), c[1] + (yz * xx - xz * xy) / (2 * det)], radius = points.reduce((s, p) => s + gap(p, center) / n, 0);
  if (!Number.isFinite(radius) || radius < tolerance * 2) return null;
  const angles = points.map((p) => Math.atan2(p[1] - center[1], p[0] - center[0]));
  let sweep = 0, reverse = 0;
  for (let i = 1; i < n; i++) {
    let d = angles[i] - angles[i - 1];
    while (d > Math.PI) d -= 2 * Math.PI;
    while (d < -Math.PI) d += 2 * Math.PI;
    sweep += d;
  }
  if (Math.abs(sweep) < 0.15 || Math.abs(sweep) > Math.PI * 1.1) return null;
  for (let i = 1; i < n; i++) {
    let d = angles[i] - angles[i - 1];
    while (d > Math.PI) d -= 2 * Math.PI;
    while (d < -Math.PI) d += 2 * Math.PI;
    if (d * sweep < 0) reverse += Math.abs(d) * radius;
  }
  if (reverse > tolerance * 2 || points.some((p) => Math.abs(gap(p, center) - radius) > tolerance * 0.85)) return null;
  const chordError = Math.min(2e-3, tolerance / 8), step = 2 * Math.acos(Math.max(-1, 1 - chordError / radius)), count2 = Math.max(2, Math.ceil(Math.abs(sweep) / step));
  if (count2 > 1024) return null;
  return { kind: "arc", chordError, points: Array.from({ length: count2 + 1 }, (_, i) => {
    const a = angles[0] + sweep * i / count2;
    return [center[0] + radius * Math.cos(a), center[1] + radius * Math.sin(a)];
  }) };
}
function partition(points, tolerance, out) {
  const line = lineFit(points, tolerance);
  if (line && contourDeviationBound(points, line.points, tolerance, false) !== null) {
    out.push(line);
    return;
  }
  const arc = circleFit(points, tolerance);
  if (arc && contourDeviationBound(points, arc.points, tolerance, false) !== null) {
    out.push(arc);
    return;
  }
  if (points.length <= 2) {
    out.push({ kind: "line", points: points.map((p) => [...p]) });
    return;
  }
  let split = 1, max = -1;
  for (let i = 1; i < points.length - 1; i++) {
    const d = dist(points[i], points[0], points.at(-1));
    if (d > max) {
      max = d;
      split = i;
    }
  }
  partition(points.slice(0, split + 1), tolerance, out);
  partition(points.slice(split), tolerance, out);
}
function joinLines(a, b, tolerance) {
  const p = a.points[0], q = b.points[0], u = [a.points[1][0] - p[0], a.points[1][1] - p[1]], v = [b.points[1][0] - q[0], b.points[1][1] - q[1]], cross = u[0] * v[1] - u[1] * v[0];
  if (Math.abs(cross) < 1e-12) return;
  const t = ((q[0] - p[0]) * v[1] - (q[1] - p[1]) * v[0]) / cross, hit = [p[0] + t * u[0], p[1] + t * u[1]];
  if (gap(hit, a.points.at(-1)) <= tolerance * 0.6 && gap(hit, b.points[0]) <= tolerance * 0.6) {
    a.points[a.points.length - 1] = hit;
    b.points[0] = hit;
  }
}
var nearest = (p, edges) => {
  let best = Infinity;
  for (const [a, b] of edges) best = Math.min(best, dist(p, a, b));
  return best;
};
function contourDeviationBound(original, candidate, tolerance, closed = true) {
  const edges = (ring) => ring.slice(0, closed ? ring.length : -1).map((p, i) => [p, ring[(i + 1) % ring.length]]);
  let bound = 0, budget = 3e5;
  function directed(from, to) {
    for (const [a, b] of edges(from)) {
      const stack = [[a, b, nearest(a, to), nearest(b, to), 0]];
      while (stack.length) {
        if (--budget < 0) return false;
        const [p, q, dp, dq, depth] = stack.pop(), length = gap(p, q);
        if (Math.max(dp, dq) > tolerance) return false;
        let upper = Infinity;
        for (const [x, y] of to) upper = Math.min(upper, Math.max(dist(p, x, y), dist(q, x, y)));
        upper = Math.min(upper, Math.max(dp, dq) + length / 2);
        if (upper <= tolerance) {
          bound = Math.max(bound, upper);
          continue;
        }
        if (depth >= 22) return false;
        const mid = [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2], dm = nearest(mid, to);
        stack.push([p, mid, dp, dm, depth + 1], [mid, q, dm, dq, depth + 1]);
      }
    }
    return true;
  }
  return directed(original, edges(candidate)) && directed(candidate, edges(original)) ? bound : null;
}
function fitRasterRing(ring, tolerance) {
  if (tolerance <= 0 || ring.length < 4) return { ring, bound: 0, lines: 0, arcs: 0, rejected: false };
  const anchors = /* @__PURE__ */ new Set();
  for (let axis = 0; axis < 2; axis++) {
    let lo = 0, hi = 0;
    for (let i = 1; i < ring.length; i++) {
      if (ring[i][axis] < ring[lo][axis]) lo = i;
      if (ring[i][axis] > ring[hi][axis]) hi = i;
    }
    anchors.add(lo);
    anchors.add(hi);
  }
  const ids = [...anchors].sort((a, b) => a - b), pieces = [];
  for (let k = 0; k < ids.length; k++) {
    const end = k + 1 < ids.length ? ids[k + 1] : ids[0] + ring.length;
    partition(Array.from({ length: end - ids[k] + 1 }, (_, i) => ring[(ids[k] + i) % ring.length]), tolerance, pieces);
  }
  for (let i = 0; i < pieces.length; i++) {
    const a = pieces[i], b = pieces[(i + 1) % pieces.length];
    if (a.kind === "line" && b.kind === "line") {
      const oldA = a.points.map((p) => [...p]), oldB = b.points.map((p) => [...p]);
      joinLines(a, b, tolerance);
      if (contourDeviationBound(oldA, a.points, tolerance * 0.2, false) === null || contourDeviationBound(oldB, b.points, tolerance * 0.2, false) === null) {
        a.points = oldA;
        b.points = oldB;
      }
    }
  }
  const candidate = [];
  for (const p of pieces) for (const point of p.points) if (!candidate.length || gap(candidate.at(-1), point) > 1e-8) candidate.push(point);
  if (candidate.length > 1 && gap(candidate[0], candidate.at(-1)) < 1e-8) candidate.pop();
  const joined = candidate.map((p) => [...p]);
  for (let pass = 0; pass < 4; pass++) {
    let changed = false;
    for (let i = candidate.length - 1; i >= 0 && candidate.length > 3; i--) {
      const p = candidate[i], a = candidate[(i + candidate.length - 1) % candidate.length], b = candidate[(i + 1) % candidate.length], deviation = dist(p, a, b);
      if (deviation < Math.min(5e-4, tolerance / 100) || Math.min(gap(a, p), gap(p, b)) < tolerance * 0.6 && deviation < tolerance * 0.5) {
        candidate.splice(i, 1);
        changed = true;
      }
    }
    if (!changed) break;
  }
  let bound = contourDeviationBound(ring, candidate, tolerance), output2 = candidate;
  if (bound === null) {
    bound = contourDeviationBound(ring, joined, tolerance);
    output2 = joined;
  }
  return bound === null ? { ring, bound: 0, lines: 0, arcs: 0, rejected: true } : { ring: output2, bound, lines: pieces.filter((p) => p.kind === "line").length, arcs: pieces.filter((p) => p.kind === "arc").length, rejected: false };
}

// src/logo-machining-optimization.js
var LOGO_MACHINING_SCHEMA = { type: "object", additionalProperties: false, properties: { enabled: { type: "boolean", default: true }, toleranceMm: { type: "number", minimum: 0, maximum: 0.1, description: "Optional explicit deviation ceiling in mm. Omitted: automatically fit to the machining endpoint within min(0.25 mm, 1% of artwork short side)." }, minDetailMm: { type: "number", minimum: 0, maximum: 1, description: "Legacy explicit-optimizer field; automatic endpoint fitting preserves all regions and holes." } } };
function validateLogoMachining(options) {
  if (options === void 0) return;
  const fail = (message) => {
    throw Object.assign(new Error(message), { code: "PARAM_SCHEMA_INVALID", path: "machining" });
  };
  if (!options || typeof options !== "object" || Array.isArray(options) || Object.keys(options).some((k) => !Object.hasOwn(LOGO_MACHINING_SCHEMA.properties, k))) fail("\u52A0\u5DE5\u4F18\u5316\u53C2\u6570\u65E0\u6548\u3002");
  if (options.enabled !== void 0 && typeof options.enabled !== "boolean") fail("machining.enabled \u5FC5\u987B\u4E3A\u5E03\u5C14\u503C\u3002");
  for (const [key, max] of [["toleranceMm", 0.1], ["minDetailMm", 1]]) if (options[key] !== void 0 && (!Number.isFinite(options[key]) || options[key] < 0 || options[key] > max)) fail(`${key} \u987B\u4E3A 0\u2013${max} mm\u3002`);
}
var rings = (regions) => regions.flatMap((r) => [r.outer, ...r.holes ?? []]);
var count = (regions) => ({ regions: regions.length, holes: regions.reduce((s, r) => s + (r.holes?.length ?? 0), 0), vertices: rings(regions).reduce((s, r) => s + r.length, 0) });
var span = (ring) => {
  let x02 = Infinity, y02 = Infinity, x12 = -Infinity, y12 = -Infinity;
  for (const [x, y] of ring) {
    x02 = Math.min(x02, x);
    x12 = Math.max(x12, x);
    y02 = Math.min(y02, y);
    y12 = Math.max(y12, y);
  }
  return Math.max(x12 - x02, y12 - y02);
};
function distance(p, a, b) {
  const dx = b[0] - a[0], dy = b[1] - a[1], d = dx * dx + dy * dy, t = d ? Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / d)) : 0;
  return Math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy);
}
function simplify(ring, tolerance) {
  if (!tolerance || ring.length < 4) return { ring, bound: 0 };
  const anchors = /* @__PURE__ */ new Set([0]);
  for (let axis = 0; axis < 2; axis++) {
    let lo = 0, hi = 0;
    for (let i = 1; i < ring.length; i++) {
      if (ring[i][axis] < ring[lo][axis]) lo = i;
      if (ring[i][axis] > ring[hi][axis]) hi = i;
    }
    anchors.add(lo);
    anchors.add(hi);
  }
  const indices = [...anchors].sort((a, b) => a - b), keep = new Set(indices);
  let bound = 0;
  for (let k = 0; k < indices.length; k++) {
    const begin = indices[k], end = k + 1 < indices.length ? indices[k + 1] : indices[0] + ring.length, stack = [[begin, end]];
    while (stack.length) {
      const [a, b] = stack.pop();
      let max = 0, furthest = -1;
      for (let i = a + 1; i < b; i++) {
        const d = distance(ring[i % ring.length], ring[a % ring.length], ring[b % ring.length]);
        if (d > max) {
          max = d;
          furthest = i;
        }
      }
      if (max > tolerance) {
        keep.add(furthest % ring.length);
        stack.push([a, furthest], [furthest, b]);
      } else bound = Math.max(bound, max);
    }
  }
  return { ring: ring.filter((_, i) => keep.has(i)), bound };
}
function fitLogoToMachining(logo2, options) {
  validateLogoMachining(options);
  const originalCapacity = inspectLogoMachiningCapacity(logo2);
  if (options?.enabled === false) return logo2;
  const original = logo2.source?.machiningOriginalContours ?? logo2;
  validateRegions(original);
  const originalRegions = structuredClone(original.regions), shortSide = Math.min(...(logo2.sizeMm ?? [35, 35]).filter((v) => v > 0));
  const ceiling = options?.toleranceMm ?? Math.min(0.25, shortSide * 0.01);
  if (!(ceiling > 0)) return logo2;
  if ((logo2.source?.kind === "raster" || logo2.source?.rasterFrame) && originalCapacity.counts.vertices > 3e3) {
    try {
      const source = { ...typeof logo2.source === "object" ? logo2.source : {} };
      delete source.machiningOptimization;
      delete source.endpointAdaptation;
      const fitted = optimizeLogoForMachining({ ...original, source }, { enabled: true, toleranceMm: Math.min(0.05, ceiling), minDetailMm: 0 }), capacity = inspectLogoMachiningCapacity(fitted), report = fitted.source.machiningOptimization;
      if (capacity.supported) return { ...fitted, source: { ...fitted.source, endpointAdaptation: { algorithm: "bounded-line-arc-topology-v2", automatic: true, before: inspectLogoMachiningCapacity(original).counts, after: capacity.counts, limits: originalCapacity.limits, maxDeviationMm: report.maxDeviationMm, allowedDeviationMm: report.toleranceMm, ceilingMm: ceiling, regionsPreserved: true, holesPreserved: true, boundsPreserved: false, nominalSizeMm: logo2.sizeMm } } };
    } catch {
    }
  }
  let accepted = null;
  for (let i = 0; i < 6; i++) {
    const tolerance = ceiling / 2 ** (5 - i), proposals = originalRegions.map((r) => ({ outer: simplify(r.outer, tolerance), holes: (r.holes ?? []).map((h) => simplify(h, tolerance)) }));
    const candidate = { ...logo2, regions: proposals.map((r) => ({ outer: r.outer.ring, holes: r.holes.map((h) => h.ring) })) };
    if (!inspectLogoMachiningCapacity(candidate).supported) continue;
    try {
      validateRegions(candidate);
    } catch {
      continue;
    }
    const bound = Math.max(0, ...proposals.flatMap((r) => [r.outer.bound, ...r.holes.map((h) => h.bound)]));
    accepted = { ...candidate, source: { ...typeof logo2.source === "object" ? logo2.source : {}, reviewed: false, reviewRequired: true, machiningOriginalContours: { type: "webcad-logo", version: 1, units: "mm", name: logo2.name, sizeMm: logo2.sizeMm, regions: originalRegions }, endpointAdaptation: { algorithm: "bounded-rdp-extrema-topology-v1", automatic: true, before: inspectLogoMachiningCapacity(original).counts, after: inspectLogoMachiningCapacity(candidate).counts, limits: originalCapacity.limits, maxDeviationMm: bound, allowedDeviationMm: tolerance, ceilingMm: ceiling, regionsPreserved: true, holesPreserved: true, boundsPreserved: true } } };
    break;
  }
  if (accepted) return accepted;
  if (originalCapacity.supported) return logo2;
  return { ...logo2, source: { ...typeof logo2.source === "object" ? logo2.source : {}, endpointAdaptation: { automatic: true, status: "unavailable-with-preserved-topology", limits: originalCapacity.limits, counts: originalCapacity.counts, ceilingMm: ceiling } } };
}
function optimizeLogoForMachining(logo2, options) {
  validateLogoMachining(options);
  if (options?.enabled !== true) return logo2;
  if (logo2.source?.machiningOptimization) throw Object.assign(new Error("\u8BF7\u4ECE\u539F\u59CB\u6765\u6E90\u91CD\u65B0\u4F18\u5316\uFF0C\u907F\u514D\u7D2F\u79EF\u8FD1\u4F3C\u3002"), { code: "LOGO_REVIEW_STALE" });
  const requestedToleranceMm = options.toleranceMm ?? 0.05, minDetailMm = options.minDetailMm ?? 0.2;
  const raster = logo2.source?.kind === "raster", shortSideMm = Math.min(...(logo2.sizeMm ?? []).filter((v) => v > 0));
  const toleranceMm = raster && Number.isFinite(shortSideMm) ? Math.min(requestedToleranceMm, shortSideMm * 0.02) : requestedToleranceMm;
  const propose = (ring) => {
    if (!raster) return simplify(ring, toleranceMm);
    const fit = fitRasterRing(ring, toleranceMm);
    try {
      validateRegions({ regions: [{ outer: fit.ring, holes: [] }] });
      if (!fit.rejected) return fit;
    } catch {
    }
    const conservative = simplify(ring, toleranceMm), bound = contourDeviationBound(ring, conservative.ring, toleranceMm);
    return bound === null ? { ring, bound: 0, lines: 0, arcs: 0, rejected: true } : { ...conservative, bound, lines: 0, arcs: 0, rejected: false, conservativeFallback: true };
  };
  validateRegions(logo2);
  const original = structuredClone(logo2.regions), before = count(original);
  let removedRegions = 0, removedHoles = 0, removedMaxSpanMm = 0;
  const regions = original.filter((r) => {
    if (minDetailMm > 0 && span(r.outer) < minDetailMm) {
      removedRegions++;
      removedMaxSpanMm = Math.max(removedMaxSpanMm, span(r.outer));
      removedHoles += (r.holes ?? []).length;
      return false;
    }
    return true;
  }).map((r) => ({ ...r, holes: (r.holes ?? []).filter((h) => {
    if (minDetailMm > 0 && span(h) < minDetailMm) {
      removedHoles++;
      removedMaxSpanMm = Math.max(removedMaxSpanMm, span(h));
      return false;
    }
    return true;
  }) }));
  if (!regions.length) throw Object.assign(new Error("\u56FE\u6848\u6240\u6709\u533A\u57DF\u5747\u5C0F\u4E8E\u5FAE\u5C0F\u7EC6\u8282\u9608\u503C\uFF0C\u8BF7\u51CF\u5C0F\u9608\u503C\u3002"), { code: "NO_VECTOR_CONTENT", details: { logoFailure: { reason: "\u56FE\u6848\u6240\u6709\u533A\u57DF\u5747\u5C0F\u4E8E\u8BBE\u5B9A\u7684\u5FAE\u5C0F\u7EC6\u8282\u5C3A\u5BF8\uFF0C\u672A\u751F\u6210\u52A0\u5DE5\u8F6E\u5ED3\u3002", next: "\u8BF7\u51CF\u5C0F\u5FAE\u5C0F\u7EC6\u8282\u9608\u503C\u540E\u91CD\u65B0\u8BC6\u522B\u3002" } } });
  validateRegions({ regions });
  let maxDeviationMm = 0, rejectedRings = 0;
  const proposals = regions.map((region) => ({ outer: propose(region.outer), holes: region.holes.map((h) => propose(h)) }));
  const batch = proposals.map((r) => ({ outer: r.outer.ring, holes: r.holes.map((h) => h.ring) }));
  let batchAccepted = false;
  try {
    validateRegions({ regions: batch });
    batchAccepted = true;
    maxDeviationMm = Math.max(0, ...proposals.flatMap((r) => [r.outer.bound, ...r.holes.map((h) => h.bound)]));
  } catch {
  }
  if (batchAccepted) regions.splice(0, regions.length, ...batch);
  else for (const region of regions) for (let h = -1; h < region.holes.length; h++) {
    const old = h < 0 ? region.outer : region.holes[h], candidate = propose(old);
    if (candidate.ring === old) continue;
    if (h < 0) region.outer = candidate.ring;
    else region.holes[h] = candidate.ring;
    try {
      validateRegions({ regions: [region] });
      for (const other of regions) if (other !== region) validateRegions({ regions: [region, other] });
      maxDeviationMm = Math.max(maxDeviationMm, candidate.bound);
    } catch {
      if (h < 0) region.outer = old;
      else region.holes[h] = old;
      rejectedRings++;
    }
  }
  const fits = proposals.flatMap((r) => [r.outer, ...r.holes]);
  const after = count(regions), report = { algorithm: raster ? "mm-line-arc-topology-v2" : "mm-rdp-extrema-topology-v1", requestedToleranceMm, toleranceMm, shortSideMm: Number.isFinite(shortSideMm) ? shortSideMm : null, tolerancePolicy: raster ? "min(requested tolerance, artwork short side * 0.02)" : "explicit-mm", minDetailMm, maxDeviationMm, before, after, removedRegions, removedHoles, removedMaxSpanMm, rejectedRings, fitting: raster ? { lineCandidates: fits.reduce((s, f) => s + (f.lines ?? 0), 0), arcCandidates: fits.reduce((s, f) => s + (f.arcs ?? 0), 0), rejectedDeviationRings: fits.filter((f) => f.rejected).length, conservativeFallbackRings: fits.filter((f) => f.conservativeFallback).length, acceptedAllCandidates: batchAccepted, curveOutput: "polyline sampled from circular arcs, then bounded join cleanup; final symmetric deviation <= toleranceMm", deviationCheck: "certified symmetric distance between complete input and output polylines" } : null, deviationAppliesTo: "retained contours only; removed compact features use minDetailMm", detailRemovalRule: "remove only whole regions/holes whose longest bounding-box dimension is below minDetailMm; retain long narrow strokes", machineCapability: "user-adjustable approximation; not verified machine/tool/depth capability", reviewRequired: true };
  const source = { ...typeof logo2.source === "object" ? logo2.source : {}, reviewed: false, reviewRequired: true, machiningOriginalContours: { type: "webcad-logo", version: 1, units: "mm", name: logo2.name, sizeMm: logo2.sizeMm, regions: original }, machiningOptimization: report };
  const points = regions.flatMap((r) => r.outer);
  let x02 = Infinity, y02 = Infinity, x12 = -Infinity, y12 = -Infinity;
  for (const [x, y] of points) {
    x02 = Math.min(x02, x);
    y02 = Math.min(y02, y);
    x12 = Math.max(x12, x);
    y12 = Math.max(y12, y);
  }
  const result = { ...logo2, sizeMm: [x12 - x02, y12 - y02], regions, source };
  result.source.machiningOptimization.machiningReadiness = inspectLogoMachiningCapacity(result);
  return result;
}

// src/logo-vector-review.js
function logoContourBounds(logo2) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const r of logo2.regions) for (const [x, y] of r.outer) {
    minX = Math.min(minX, x);
    minY = Math.min(minY, y);
    maxX = Math.max(maxX, x);
    maxY = Math.max(maxY, y);
  }
  return [minX, minY, maxX, maxY];
}

// src/logo-width.js
var inputError = (message, code) => Object.assign(new Error(message), { code });
function fitLogoWidth(logo2, targetWidthMm) {
  if (targetWidthMm === void 0) return logo2;
  if (!(Number.isFinite(targetWidthMm) && targetWidthMm > 0)) throw inputError("\u56FE\u6848\u5BBD\u5EA6\u5FC5\u987B\u5927\u4E8E 0 mm\u3002", "SIZE_REQUIRED");
  const points = logo2.regions.flatMap((r) => r.outer), xs = points.map((p) => p[0]), ys = points.map((p) => p[1]);
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (let i = 0; i < xs.length; i++) {
    minX = Math.min(minX, xs[i]);
    maxX = Math.max(maxX, xs[i]);
    minY = Math.min(minY, ys[i]);
    maxY = Math.max(maxY, ys[i]);
  }
  const width2 = maxX - minX, factor = targetWidthMm / width2;
  if (!(width2 > 0 && Number.isFinite(factor))) throw inputError("\u6CA1\u6709\u53EF\u7F29\u653E\u7684\u6709\u6548 LOGO \u8F6E\u5ED3\u3002", "INVALID_CONTOUR");
  const frame = logo2.source?.rasterFrame, rasterFrame = frame ? { ...frame, ...Object.fromEntries(["xMm", "yMm", "widthMm", "heightMm", "mmPerPixel"].map((key) => [key, frame[key] * factor])) } : void 0;
  const scaledReport = (report, keys) => report ? { ...report, ...Object.fromEntries(keys.filter((key) => Number.isFinite(report[key])).map((key) => [key, report[key] * factor])) } : report;
  const rasterSmoothing = scaledReport(logo2.source?.rasterSmoothing, ["requestedToleranceMm", "effectiveToleranceMm", "curveDistanceUpperBoundMm", "coordinateRoundingMm"]);
  const rasterTopology = scaledReport(logo2.source?.rasterTopology, ["curveDistanceUpperBoundMm"]);
  const conversionReport = scaledReport(logo2.source?.conversionReport, ["requestedToleranceMm", "approximationBoundMm"]);
  const conversion = scaledReport(logo2.source?.conversion, ["requestedToleranceMm", "approximationBoundMm"]);
  const rasterOriginalContoursToLogo = logo2.source?.rasterOriginalContours ? { scale: (logo2.source.rasterOriginalContoursToLogo?.scale ?? 1) * factor, translationMm: [0, 0], from: "converter-original-mm", to: "logo-mm" } : void 0;
  return { ...logo2, sizeMm: [targetWidthMm, (maxY - minY) * factor], regions: logo2.regions.map((r) => ({ outer: r.outer.map((p) => p.map((v) => v * factor)), holes: (r.holes || []).map((h) => h.map((p) => p.map((v) => v * factor))) })), source: { ...typeof logo2.source === "object" ? logo2.source : { original: logo2.source }, ...rasterFrame ? { rasterFrame } : {}, ...rasterSmoothing ? { rasterSmoothing } : {}, ...rasterTopology ? { rasterTopology } : {}, ...conversionReport ? { conversionReport } : {}, ...conversion ? { conversion } : {}, ...rasterOriginalContoursToLogo ? { rasterOriginalContoursToLogo } : {}, widthNormalization: { basis: "contour-bounds", convertedWidthMm: width2, requestedWidthMm: targetWidthMm, scale: factor } } };
}

// src/agent/logo-preparer.mjs
var [input, output, preview] = process.argv.slice(2);
if (!input || !output || !preview) throw new Error("Expected input, output and preview paths supplied by the host.");
var raw = JSON.parse(readFileSync(input, "utf8"));
var packet = raw.logoDocument ?? raw.logo ?? raw;
if (packet.type !== "webcad-logo" || packet.version !== 1 || packet.units !== "mm") throw new Error("Expected a millimeter LOGO document.");
var width = process.argv[5] ? Number(process.argv[5]) : raw.targetWidthMm ?? void 0;
var sized = fitLogoWidth(packet, width);
var logo = packet.source?.contourEditing ? sized : fitLogoToMachining(sized, raw.machining ?? void 0);
validateRegions(logo);
var text = JSON.stringify(logo);
var bytes = Buffer.from(text);
var hash = createHash("sha256").update(bytes).digest("hex");
writeFileSync(output, bytes);
var [x0, y0, x1, y1] = logoContourBounds(logo);
var pad = Math.max(x1 - x0, y1 - y0) * 0.05;
var paths = logo.regions.map((r) => `<path fill-rule="evenodd" d="${[r.outer, ...r.holes ?? []].map((ring) => ring.map(([x, y], i) => `${i ? "L" : "M"}${x} ${-y}`).join(" ") + " Z").join(" ")}"/>`).join("");
writeFileSync(preview, `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${x0 - pad} ${-y1 - pad} ${x1 - x0 + pad * 2} ${y1 - y0 + pad * 2}"><g fill="#296a89">${paths}</g></svg>`);
console.log(JSON.stringify({ status: "vectorized", size: bytes.length, sha256: hash, capacity: inspectLogoMachiningCapacity(logo), adaptation: logo.source?.endpointAdaptation ?? null }));
